"""
amyloid_model_v2.py
=====================================================================
Two jobs:
 (1) Honest model-improvement EXPLORATION on the Abeta data we already
     have. Adds two PRINCIPLED features to the base in-register model:
        +beta     : Chou-Fasman beta-sheet propensity (aggregation likes
                    beta-prone residues)
        +neighbor : nearest-neighbor hydrophobic packing along the strand
                    (a crude steric-zipper / hydrophobic-patch term)
     Weights are pre-declared (NOT tuned to the DMS test set). All variants
     are reported transparently; the held-out IAPP data (tomorrow) is the
     real arbiter of whether any improvement generalizes.
 (2) Generate IAPP single-mutant predictions, ready to correlate the moment
     the IAPP DMS file is uploaded.
"""
import sys, glob
import numpy as np, pandas as pd
sys.path.insert(0, ".")
import abeta42_dms_validation as M          # base scales + spearman

ABETA42 = M.ABETA42
IAPP    = "KCNTATCATQRLANFLVHSSNNFGAILSSTNVGSNTY"   # human amylin, 37 aa
AAS     = "ACDEFGHIKLMNPQRSTVWY"

# Chou-Fasman beta-sheet propensity (Pbeta); >1 = beta-prone
PBETA = {'A':0.83,'R':0.93,'N':0.89,'D':0.54,'C':1.19,'Q':1.10,'E':0.37,
         'G':0.75,'H':0.87,'I':1.60,'L':1.30,'K':0.74,'M':1.05,'F':1.38,
         'P':0.55,'S':0.75,'T':1.19,'W':1.37,'Y':1.47,'V':1.70}

# pre-declared weights (NOT fitted to DMS)
W_HYDRO, W_REPULS = 1.0, 2.0
W_BETA, W_NB = 1.0, 0.5

def propensity(seq, beta=False, neighbor=False):
    n = len(seq); s = 0.0
    for i in range(n):
        a = seq[i]
        s += W_HYDRO * max(0.0, M.hydro(a))**2 / 10.0      # hydrophobic burial
        s += -W_REPULS * M.charge(a)**2                     # like-charge repulsion
        if beta:
            s += W_BETA * (PBETA[a] - 1.0)                  # beta-propensity
        if neighbor:
            for j in (i - 1, i + 1):                        # along-strand packing
                if 0 <= j < n:
                    s += W_NB * max(0.0, M.hydro(a)) * max(0.0, M.hydro(seq[j])) / 10.0
    return s

def all_deltas(seq, **kw):
    wt = propensity(seq, **kw); out = {}
    for pos in range(1, len(seq) + 1):
        w = seq[pos - 1]
        for m in AAS:
            if m == w: continue
            mut = seq[:pos - 1] + m + seq[pos:]
            out[f"{w}{pos}{m}"] = propensity(mut, **kw) - wt
    return out

VARIANTS = [("v0 base", {}), ("v1 +beta", {"beta": True}),
            ("v2 +neighbor", {"neighbor": True}),
            ("v3 +beta+neighbor", {"beta": True, "neighbor": True})]

def load_abeta_dms():
    f = glob.glob("/sessions/*/mnt/uploads/*supp4*.xlsx") or glob.glob("*supp4*.xlsx")
    df = pd.read_excel(f[0], sheet_name="1 aa change")
    df = df[(df["STOP"] == False) & (df["Mut"].isin(set(AAS))) & df["nscore"].notna()].copy()
    df["variant"] = (df["WT_AA"].astype(str) + df["Pos"].astype(int).astype(str)
                     + df["Mut"].astype(str))
    return dict(zip(df["variant"], df["nscore"]))

def gatekeeper_rho(deltas, dms):
    gate = {1, 3, 7, 11, 17, 22, 42}
    def pos(v): return int("".join(c for c in v[1:-1]))
    common = [v for v in deltas if v in dms and pos(v) in gate]
    if len(common) < 6: return float("nan")
    return M.spearman(np.array([deltas[v] for v in common]),
                      np.array([dms[v] for v in common]))

def main():
    dms = load_abeta_dms()
    print("=" * 66)
    print("Abeta42: does adding principled physics help? (honest, untuned)")
    print("=" * 66)
    print(f"{'variant':20s} {'n':>4s} {'Spearman(all)':>14s} {'gatekeepers':>12s}")
    for name, kw in VARIANTS:
        d = all_deltas(ABETA42, **kw)
        common = [v for v in d if v in dms]
        mv = np.array([d[v] for v in common]); dv = np.array([dms[v] for v in common])
        print(f"{name:20s} {len(common):4d} {M.spearman(mv, dv):+14.3f} "
              f"{gatekeeper_rho(d, dms):+12.3f}")
    print("\nNOTE: pick NOTHING as 'the winner' from Abeta alone -- that would be"
          "\nfitting to the test set. IAPP (held out) decides which variant, if any,"
          "\ngenuinely generalizes. Report all of the above honestly.")

    # ---- IAPP predictions (ready for the uploaded IAPP DMS) ----
    print("\nWriting IAPP single-mutant predictions (base + best-guess v3)...")
    for tag, kw in [("base", {}), ("beta_neighbor", {"beta": True, "neighbor": True})]:
        d = all_deltas(IAPP, **kw)
        pd.DataFrame([(v, d[v]) for v in d], columns=["variant", "model_delta"]) \
          .to_csv(f"iapp_model_predictions_{tag}.csv", index=False)
        print(f"  iapp_model_predictions_{tag}.csv  ({len(d)} single mutants)")
    print("\nWhen you upload the IAPP DMS file, we match on variant (WT_aa+pos+mut)"
          "\nand compute the two-amyloid generality number.")

if __name__ == "__main__":
    main()
