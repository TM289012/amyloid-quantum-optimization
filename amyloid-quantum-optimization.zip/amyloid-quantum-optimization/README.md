# A minimal quantum-optimization model of amyloid aggregation (amyloid-β and IAPP)

Proof-of-concept code accompanying the manuscript
"A minimal quantum-optimization model of amyloid aggregation generalizes across
two disease amyloids (amyloid-β and IAPP)."

## What this does
It casts the two-chain β-sheet assembly of an amyloid peptide as a quantum-optimization
(QUBO) problem solved with the Quantum Approximate Optimization Algorithm (QAOA),
scored by a deliberately minimal, non-energy objective (hydrophobic burial rewarded,
like-charge repulsion penalized). The same fixed model, unchanged, is validated against
experimental deep mutational scanning (DMS) of two disease amyloids:

- Amyloid-β (Alzheimer's): Spearman ρ = +0.35 across 468 single mutants
- IAPP (type-2 diabetes): Spearman ρ = +0.25 across 699 single mutants

Predictive signal concentrates in the structured hydrophobic core of both peptides.

Honest scope: this is a proof of concept, not a state-of-the-art predictor. The QAOA
instance is small and simulated on a statevector simulator, so no quantum speed-up is
claimed.

## Files
- aggregation_qopt.py         β-sheet registry model + QAOA (statevector) + MD cross-check
- abeta42_dms_validation.py   full Aβ42 model; scores all single mutants; stats helpers
- abeta42_dms_correlate.py    correlate Aβ model vs eLife DMS (produces Figure 2)
- two_amyloid_validation.py   same model on Aβ + IAPP; two-panel figure (produces Figure 1)
- amyloid_model_v2.py         model-improvement exploration + IAPP predictions

## Data (download from the original studies; not redistributed here)
- Aβ DMS: Seuma et al., eLife 2021 (article 63364), Supplementary file 4
- IAPP DMS: Badia et al., Nat Commun 2026 (GEO GSE281555), Supplementary Data (MOESM4)
Place the downloaded .xlsx files in this folder; adjust the file paths near the top of
each script if needed.

## Requirements
Python >= 3.9 with: numpy, pandas, matplotlib, openpyxl
(optional, for a real-hardware run: qiskit, qiskit-optimization, qiskit-aer)

    pip install -r requirements.txt

## Run
    python two_amyloid_validation.py   # main result + Figure 1
    python abeta42_dms_correlate.py    # Aβ detail + Figure 2

## AI-assistance note
Computational and drafting assistance was provided by an AI system; all analyses were
generated, verified, and interpreted by the author.

## License
MIT
