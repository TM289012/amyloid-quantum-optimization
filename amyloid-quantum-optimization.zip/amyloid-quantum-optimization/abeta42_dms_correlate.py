"""
abeta42_dms_correlate.py
=====================================================================
STAGE 2: validate the quantum-opt aggregation model against the eLife
deep mutational scanning data (Seuma et al. 2021, Supplementary file 4).

Reads the '1 aa change' sheet (468 single missense mutants, column
'nscore' = merged nucleation score; positive = faster aggregation),
matches to the model's per-mutant predictions, and reports:
  * overall Spearman + Pearson + p
  * regional breakdown (C-term hydrophobic core vs N-term vs gatekeepers)
  * familial-mutation agreement
  * single-feature baselines (does the model beat raw dHydrophobicity /
    dCharge? -- honesty check)
  * a scatter figure.

Usage:  python3 abeta42_dms_correlate.py  /path/to/elife-63364-supp4-v2.xlsx
"""
import sys, glob
import numpy as np
import pandas as pd
import abeta42_dms_validation as M   # model + stats live here

def find_file(argv):
    if len(argv) > 1:
        return argv[1]
    for pat in ("*supp4*.xlsx",
                "/sessions/*/mnt/uploads/*supp4*.xlsx",
                "*63364*supp4*.xlsx"):
        hits = glob.glob(pat)
        if hits:
            return hits[0]
    raise SystemExit("Give the path to elife-63364-supp4-v2.xlsx")

def main():
    path = find_file(sys.argv)
    # ---- model predictions ----
    wt, rows = M.all_single_mutants()
    model = {r[0]: r[5] for r in rows}            # variant -> delta vs WT
    hyd   = {r[0]: M.hydro(r[3]) - M.hydro(r[2]) for r in rows}   # d hydrophobicity
    # d(self-repulsion relief) = q_wt^2 - q_mut^2  (positive = charge removed)
    chg   = {r[0]: M.charge(r[2])**2 - M.charge(r[3])**2 for r in rows}

    # ---- DMS nucleation scores (single missense) ----
    df = pd.read_excel(path, sheet_name="1 aa change")
    AAS = set("ACDEFGHIKLMNPQRSTVWY")
    df = df[(df["STOP"] == False) & (df["Mut"].isin(AAS)) & df["nscore"].notna()].copy()
    df["variant"] = (df["WT_AA"].astype(str) + df["Pos"].astype(int).astype(str)
                     + df["Mut"].astype(str))
    dms = dict(zip(df["variant"], df["nscore"]))

    common = sorted(v for v in model if v in dms)
    mv = np.array([model[v] for v in common])
    dv = np.array([dms[v]   for v in common])
    n = len(common)

    rho = M.spearman(mv, dv); p = M.spearman_p(rho, n)
    pear = float(np.corrcoef(mv, dv)[0, 1])
    print("=" * 70)
    print(f"MODEL vs DMS nucleation   (n = {n} single mutants)")
    print("=" * 70)
    print(f"Spearman = {rho:+.3f}   p = {p:.1e}")
    print(f"Pearson  = {pear:+.3f}")

    print("\nSingle-feature baselines (does the model add anything?):")
    for name, d in [("d hydrophobicity", hyd), ("charge removed (q^2)", chg)]:
        bv = np.array([d[v] for v in common])
        print(f"  {name:22s} Spearman vs DMS = {M.spearman(bv, dv):+.3f}")

    def pos_of(v): return int("".join(c for c in v[1:-1]))
    gate = {1, 3, 7, 11, 17, 22, 42}
    regions = [("C-term core 27-41", set(range(27, 42))),
               ("N-term 2-26",       set(range(2, 27))),
               ("gatekeepers",        gate)]
    print("\nRegional breakdown (where the coarse model works):")
    reg_of = {}
    for nm, sel in regions:
        idx = [i for i, v in enumerate(common) if pos_of(v) in sel]
        for i in idx: reg_of.setdefault(i, nm)
        if len(idx) > 5:
            print(f"  {nm:20s} n={len(idx):3d}  Spearman={M.spearman(mv[idx], dv[idx]):+.3f}")

    fam = {"H6R":"English","D7N":"Tottori","A21G":"Flemish","E22G":"Arctic",
           "E22Q":"Dutch","E22K":"Italian","D23N":"Iowa"}
    print("\nFamilial mutations (DMS>0 = experimentally more aggregation-prone):")
    agree = 0
    for v, nm in sorted(fam.items()):
        if v in dms:
            a = (model[v] > 0) == (dms[v] > 0); agree += a
            print(f"  {nm:8s} {v:5s} model={model[v]:+.2f}  DMS={dms[v]:+.2f}"
                  f"  [{'agree' if a else 'MISS'}]")
    print(f"  -> {agree}/7 directional agreement")

    # ---- figure ----
    try:
        import matplotlib; matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        colors = {"C-term core 27-41": "#c0392b", "N-term 2-26": "#2c6fbb",
                  "gatekeepers": "#e0a11e", None: "#9aa0a6"}
        fig, ax = plt.subplots(figsize=(7.2, 5.2))
        for nm in ["N-term 2-26", "C-term core 27-41", "gatekeepers"]:
            idx = [i for i in range(n) if reg_of.get(i) == nm]
            ax.scatter(mv[idx], dv[idx], s=16, alpha=0.6, color=colors[nm], label=nm)
        for v, nm in fam.items():
            if v in dms:
                ax.scatter([model[v]], [dms[v]], s=90, marker="*",
                           edgecolor="k", facecolor="gold", zorder=5)
                ax.annotate(v, (model[v], dms[v]), fontsize=8,
                            xytext=(4, 4), textcoords="offset points")
        ax.axhline(0, color="grey", lw=.7); ax.axvline(0, color="grey", lw=.7)
        ax.set_xlabel("model aggregation propensity change (vs WT)")
        ax.set_ylabel("experimental nucleation score (eLife DMS)")
        ax.set_title(f"Quantum-opt model vs deep mutational scanning\n"
                     f"n={n}, Spearman={rho:+.2f} (p={p:.0e}); stars = familial")
        ax.legend(frameon=False, fontsize=8, loc="lower right")
        fig.tight_layout(); fig.savefig("figure_model_vs_dms.png", dpi=300)
        print("\n[figure saved] figure_model_vs_dms.png")
    except Exception as e:
        print("[figure skipped]", e)

if __name__ == "__main__":
    main()
