"""
abeta42_dms_validation.py
=====================================================================
Upgrade the quantum-opt aggregation model from a 4-point MD check to a
LARGE experimental validation against deep mutational scanning (DMS).

Two stages:
  STAGE 1 (runs now, no external data):
     Apply the in-register cross-beta aggregation model to FULL Abeta42
     and score every single-point mutant (~798). Export predictions and
     report where the known familial single-substitution mutations rank.

  STAGE 2 (runs once you upload the eLife data):
     Merge the model's per-mutant predictions with the experimentally
     measured nucleation scores from Seuma et al., eLife 2021
     (Supplementary file 1: 468 single mutants), and compute the Spearman
     correlation + p-value. THAT correlation is the standalone-paper result.

Model recap (same as the PoC, principled not tuned):
  Abeta amyloid = parallel, in-register cross-beta. Aggregation propensity
  is read on that stack: hydrophobic burial rewarded, LIKE charges repel.
  A single mutation at position i only changes the (i,i) self-pair, so this
  is an intrinsic per-residue hydrophobicity+charge model. It is therefore
  LOCAL by construction: it cannot see position-specific "gatekeeper"
  context, and it scores a charge swap (e.g. E->K) as ~neutral because it
  only sees charge magnitude. Those are honest, expected blind spots.
"""

import csv
import math
import numpy as np

# ================================================================== #
# Full Abeta(1-42).  Residues 21-30 (AEDVGSNKGA) match the PoC fragment.
# ================================================================== #
ABETA42 = "DAEFRHDSGYEVHHQKLVFFAEDVGSNKGAIIGLMVGGVVIA"
assert len(ABETA42) == 42
AAS = "ACDEFGHIKLMNPQRSTVWY"

KD_HYDRO = {
    'A': 1.8, 'R': -4.5, 'N': -3.5, 'D': -3.5, 'C': 2.5, 'Q': -3.5, 'E': -3.5,
    'G': -0.4, 'H': -3.2, 'I': 4.5, 'L': 3.8, 'K': -3.9, 'M': 1.9, 'F': 2.8,
    'P': -1.6, 'S': -0.8, 'T': -0.7, 'W': -0.9, 'Y': -1.3, 'V': 4.2}
CHARGE = {'D': -1.0, 'E': -1.0, 'K': 1.0, 'R': 1.0, 'H': 0.1}

def hydro(aa):  return KD_HYDRO[aa]
def charge(aa): return CHARGE.get(aa, 0.0)

W_HYDRO, W_REPULS, W_OPP = 1.0, 2.0, 0.5           # fixed, not fitted to DMS

def pair_score(a, b):
    hh = max(0.0, hydro(a)) * max(0.0, hydro(b)) / 10.0
    qq = charge(a) * charge(b)
    electro = -W_REPULS * qq if qq > 0 else -W_OPP * qq
    return W_HYDRO * hh + electro

def inregister_propensity(seq):
    """Aggregation propensity = parallel in-register self-stack score
    (backbone/cross-beta term is constant for fixed length, so omitted:
    it cancels in every mutant-vs-WT comparison and every correlation)."""
    return sum(pair_score(seq[i], seq[i]) for i in range(len(seq)))

# ================================================================== #
# Known familial single-substitution mutations (Abeta numbering)
# ================================================================== #
FAMILIAL = {"H6R": "English", "D7N": "Tottori", "A21G": "Flemish",
            "E22G": "Arctic", "E22Q": "Dutch", "E22K": "Italian", "D23N": "Iowa"}

# ================================================================== #
# STAGE 1: score all single mutants
# ================================================================== #
def all_single_mutants():
    wt = inregister_propensity(ABETA42)
    rows = []
    for pos in range(1, 43):
        wt_aa = ABETA42[pos - 1]
        for mut in AAS:
            if mut == wt_aa:
                continue
            seq = ABETA42[:pos - 1] + mut + ABETA42[pos:]
            prop = inregister_propensity(seq)
            rows.append([f"{wt_aa}{pos}{mut}", pos, wt_aa, mut, prop, prop - wt])
    return wt, rows

def _ranks(a):
    a = np.asarray(a, float); n = len(a); order = np.argsort(a, kind="mergesort")
    r = np.empty(n); i = 0
    while i < n:
        j = i
        while j + 1 < n and a[order[j + 1]] == a[order[i]]:
            j += 1
        for k in range(i, j + 1):
            r[order[k]] = (i + j) / 2.0
        i = j + 1
    return r

def spearman(x, y):
    rx, ry = _ranks(x), _ranks(y); rx -= rx.mean(); ry -= ry.mean()
    d = math.sqrt((rx**2).sum() * (ry**2).sum())
    return float((rx*ry).sum()/d) if d else 0.0

def spearman_p(r, n):
    if n < 4 or abs(r) >= 1:
        return float("nan")
    t = r * math.sqrt((n - 2) / (1 - r*r))
    return 2.0 * (1.0 - 0.5*(1.0 + math.erf(abs(t)/math.sqrt(2))))   # normal approx

def stage1(path="abeta42_model_predictions.csv"):
    wt, rows = all_single_mutants()
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["variant", "position", "wt_aa", "mut_aa",
                    "model_propensity", "model_delta_vs_wt"])
        w.writerows(rows)
    N = len(rows)
    deltas = np.array([r[5] for r in rows])
    ranks = np.empty(N, int); ranks[np.argsort(-deltas)] = np.arange(1, N + 1)
    rank_of = {rows[i][0]: int(ranks[i]) for i in range(N)}
    delta_of = {rows[i][0]: rows[i][5] for i in range(N)}

    print("=" * 68)
    print(f"STAGE 1  |  WT propensity = {wt:.3f}   |   {N} single mutants scored")
    print(f"          predictions written -> {path}")
    print("=" * 68)
    print("Familial single mutations, ranked by the model among all mutants")
    print("(rank 1 = most aggregation-promoting; delta>0 = model says MORE):")
    hits = 0
    for var, name in FAMILIAL.items():
        if var in rank_of:
            d, rk = delta_of[var], rank_of[var]
            flag = "OK " if d > 0 else "MISS"
            hits += (d > 0)
            print(f"  {name:9s} {var:6s}  delta={d:+.3f}  rank {rk:4d}/{N} "
                  f"(top {100*rk/N:4.0f}%)   [{flag}]")
    print(f"\nModel calls {hits}/{len(FAMILIAL)} familial mutations aggregation-promoting.")
    print("Expected honest blind spots: charge-swap (E22K) and hydrophobic-loss")
    print("(A21G) mutations, plus charge-adding ones (H6R), which a magnitude-only")
    print("charge + hydrophobicity model cannot get right.")
    return path

# ================================================================== #
# STAGE 2: correlate with the eLife DMS nucleation scores
#   Upload Seuma et al. 2021 Supplementary file 1, save as CSV, then:
#     python3 abeta42_dms_validation.py dms.csv variant_col score_col
#   (column names auto-detected if you omit them)
# ================================================================== #
def _read_dms(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    cols = rows[0].keys() if rows else []
    return rows, list(cols)

def _guess(cols, options):
    low = {c.lower(): c for c in cols}
    for o in options:
        for lc, orig in low.items():
            if o in lc:
                return orig
    return None

def stage2(dms_csv, var_col=None, score_col=None):
    rows, cols = _read_dms(dms_csv)
    print("=" * 68)
    print(f"STAGE 2  |  DMS file: {dms_csv}")
    print("columns found:", cols)
    var_col = var_col or _guess(cols, ["variant", "mutant", "mut", "aa_subs", "id"])
    score_col = score_col or _guess(cols, ["nucleation", "score", "fitness", "effect"])
    print(f"using variant column = {var_col!r}, score column = {score_col!r}")
    if not var_col or not score_col:
        print("Could not auto-detect columns; rerun with explicit names:")
        print("  python3 abeta42_dms_validation.py dms.csv <variant_col> <score_col>")
        return

    dms = {}
    for r in rows:
        v = (r.get(var_col) or "").strip().replace(" ", "")
        try:
            dms[v] = float(r.get(score_col))
        except (TypeError, ValueError):
            continue

    _, mrows = all_single_mutants()
    model = {r[0]: r[5] for r in mrows}                    # variant -> model delta
    common = [v for v in model if v in dms]
    print(f"matched {len(common)} variants between model and DMS")
    if len(common) < 10:
        print("Few matches -> variant naming differs (e.g. 'E22G' vs 'Glu22Gly' vs"
              " position index). Tell me the format and I'll adapt the parser.")
        return

    mv = np.array([model[v] for v in common])
    dv = np.array([dms[v] for v in common])
    rho = spearman(mv, dv); p = spearman_p(rho, len(common))
    print("-" * 68)
    print(f"Spearman(model_delta, DMS_nucleation) = {rho:+.3f}   "
          f"p = {p:.2e}   (n={len(common)})")
    fam = [v for v in common if v in FAMILIAL]
    if fam:
        rho_f = spearman(np.array([model[v] for v in fam]),
                         np.array([dms[v] for v in fam]))
        print(f"familial subset (n={len(fam)}): Spearman = {rho_f:+.3f}   {fam}")
    print("\nInterpret honestly: a modest-but-significant rho across hundreds of"
          " mutations is a real result; near-zero says the coarse model needs"
          " position/context terms (the honest next step).")

# ================================================================== #
if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 2:                # STAGE 2 if a DMS file is given
        stage2(sys.argv[1],
               sys.argv[2] if len(sys.argv) > 2 else None,
               sys.argv[3] if len(sys.argv) > 3 else None)
    else:
        stage1()
