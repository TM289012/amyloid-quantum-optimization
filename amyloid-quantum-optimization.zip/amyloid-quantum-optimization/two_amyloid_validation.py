"""
two_amyloid_validation.py
=====================================================================
GENERALITY TEST: the SAME minimal aggregation model (in-register cross-beta,
hydrophobic burial minus like-charge repulsion), applied to two different
disease amyloids, validated against two independent deep-mutational-scanning
datasets:

  * Abeta42  (Alzheimer's)     -- Seuma et al., eLife 2021,  n = 468 singles
  * IAPP     (type-2 diabetes) -- Badia et al., Nat Commun 2026, n = 699 singles

Same model, same weights, no per-dataset tuning. Reports Spearman/Pearson + p
for each amyloid, an IAPP structured-core breakdown, and a two-panel figure.
"""
import glob, re, sys
import numpy as np, pandas as pd
sys.path.insert(0, ".")
import abeta42_dms_validation as M            # hydro/charge scales + spearman

ABETA42 = M.ABETA42
IAPP    = "KCNTATCATQRLANFLVHSSNNFGAILSSTNVGSNTY"   # human amylin, 37 aa
AAS     = "ACDEFGHIKLMNPQRSTVWY"
W_HYDRO, W_REPULS = 1.0, 2.0                  # same weights for BOTH amyloids

def propensity(seq):
    return sum(W_HYDRO * max(0.0, M.hydro(a))**2 / 10.0 - W_REPULS * M.charge(a)**2
               for a in seq)

def model_deltas(seq):
    wt = propensity(seq); out = {}
    for pos in range(1, len(seq) + 1):
        w = seq[pos - 1]
        for m in AAS:
            if m != w:
                out[f"{w}{pos}{m}"] = propensity(seq[:pos-1]+m+seq[pos:]) - wt
    return out

# ---------- experimental data loaders ----------
def load_abeta():
    f = glob.glob("/sessions/*/mnt/uploads/*supp4*.xlsx") or glob.glob("*supp4*.xlsx")
    df = pd.read_excel(f[0], sheet_name="1 aa change")
    df = df[(df["STOP"] == False) & (df["Mut"].isin(set(AAS))) & df["nscore"].notna()]
    v = df["WT_AA"].astype(str) + df["Pos"].astype(int).astype(str) + df["Mut"].astype(str)
    return dict(zip(v, df["nscore"]))

_T2O = {'Ala':'A','Arg':'R','Asn':'N','Asp':'D','Cys':'C','Gln':'Q','Glu':'E','Gly':'G',
        'His':'H','Ile':'I','Leu':'L','Lys':'K','Met':'M','Phe':'F','Pro':'P','Ser':'S',
        'Thr':'T','Trp':'W','Tyr':'Y','Val':'V'}
def load_iapp():
    f = glob.glob("/sessions/*/mnt/uploads/*MOESM4_ESM.xlsx") or glob.glob("*MOESM4_ESM.xlsx")
    df = pd.read_excel(f[0]); df = df[df["Mutation_type"] == "Singles"].copy()
    def parse(h):
        m = re.match(r"p\.([A-Z][a-z]{2})(\d+)([A-Z][a-z]{2})$", str(h))
        if m and m.group(1) in _T2O and m.group(3) in _T2O:
            return f"{_T2O[m.group(1)]}{m.group(2)}{_T2O[m.group(3)]}"
        return None
    df["variant"] = df["HGVS_nomenclature"].map(parse)
    df = df.dropna(subset=["variant", "fitness_merged"])
    return dict(zip(df["variant"], df["fitness_merged"]))

def correlate(model, dms):
    common = sorted(set(model) & set(dms))
    mv = np.array([model[v] for v in common]); dv = np.array([float(dms[v]) for v in common])
    return common, mv, dv, M.spearman(mv, dv), M.spearman_p(M.spearman(mv, dv), len(common))

def pos_of(v): return int("".join(c for c in v[1:-1]))

def main():
    ab_m, ia_m = model_deltas(ABETA42), model_deltas(IAPP)
    ab_d, ia_d = load_abeta(), load_iapp()
    (abc, abx, aby, ab_rho, ab_p) = correlate(ab_m, ab_d)
    (iac, iax, iay, ia_rho, ia_p) = correlate(ia_m, ia_d)

    print("=" * 64)
    print("SAME MODEL, TWO DISEASE AMYLOIDS")
    print("=" * 64)
    print(f"Abeta42 (Alzheimer's) : Spearman {ab_rho:+.3f}  p={ab_p:.1e}  n={len(abc)}")
    print(f"IAPP    (T2 diabetes) : Spearman {ia_rho:+.3f}  p={ia_p:.1e}  n={len(iac)}")

    core = set(range(15, 33))                 # IAPP structured core (paper: 15-32)
    ci = [k for k, v in enumerate(iac) if pos_of(v) in core]
    ni = [k for k, v in enumerate(iac) if pos_of(v) not in core]
    print(f"\nIAPP core (15-32)   n={len(ci):3d}  Spearman={M.spearman(iax[ci], iay[ci]):+.3f}")
    print(f"IAPP non-core       n={len(ni):3d}  Spearman={M.spearman(iax[ni], iay[ni]):+.3f}")
    print("\nSame model, same weights, two independent datasets, no per-set tuning.")

    # ---------- two-panel figure ----------
    try:
        import matplotlib; matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(1, 2, figsize=(11, 4.6))
        ax[0].scatter(abx, aby, s=14, alpha=0.5, color="#c0392b")
        ax[0].set_title(f"Abeta42 - Alzheimer's\nSpearman {ab_rho:+.2f} (p={ab_p:.0e}, n={len(abc)})")
        ax[1].scatter(iax, iay, s=14, alpha=0.5, color="#2c6fbb")
        ax[1].set_title(f"IAPP - type-2 diabetes\nSpearman {ia_rho:+.2f} (p={ia_p:.0e}, n={len(iac)})")
        for a in ax:
            a.axhline(0, color="grey", lw=.6); a.axvline(0, color="grey", lw=.6)
            a.set_xlabel("model aggregation propensity change (vs WT)")
            a.set_ylabel("experimental nucleation score")
        fig.suptitle("One minimal quantum-optimization model, two disease amyloids", y=1.02)
        fig.tight_layout(); fig.savefig("figure_two_amyloids.png", dpi=300, bbox_inches="tight")
        print("[figure saved] figure_two_amyloids.png")
    except Exception as e:
        print("[figure skipped]", e)

if __name__ == "__main__":
    main()
